Overview of Microsoft WinRM Tools
=================================

winrm
-----

Ping. Is winrm service up? No authentication.

    winrm id -r:hostname -a:none


winrs
-----

*TODO: put info about winrs here*

wecutil
-------

*TODO: put info about wecutil here*
